--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
ALTER TABLE ONLY public.registered_user_for_publications DROP CONSTRAINT registered_user_for_publications_pkey;
ALTER TABLE ONLY public.publications DROP CONSTRAINT publications_pkey;
ALTER TABLE ONLY public.publication_reports DROP CONSTRAINT publication_reports_pkey;
ALTER TABLE ONLY public.active_devices DROP CONSTRAINT active_devices_pkey;
ALTER TABLE public.registered_user_for_publications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.publications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.publication_reports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.active_devices ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.registered_user_for_publications_id_seq;
DROP TABLE public.registered_user_for_publications;
DROP SEQUENCE public.publications_id_seq;
DROP TABLE public.publications;
DROP SEQUENCE public.publication_reports_id_seq;
DROP TABLE public.publication_reports;
DROP SEQUENCE public.active_devices_id_seq;
DROP TABLE public.active_devices;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: orrbarkat
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO orrbarkat;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: orrbarkat
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: active_devices; Type: TABLE; Schema: public; Owner: orrbarkat; Tablespace: 
--

CREATE TABLE active_devices (
    id integer NOT NULL,
    remote_notification_token character varying(256) NOT NULL,
    is_ios boolean,
    last_location_latitude numeric NOT NULL,
    last_location_longitude numeric NOT NULL,
    dev_uuid character varying(64) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE active_devices OWNER TO orrbarkat;

--
-- Name: active_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: orrbarkat
--

CREATE SEQUENCE active_devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE active_devices_id_seq OWNER TO orrbarkat;

--
-- Name: active_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orrbarkat
--

ALTER SEQUENCE active_devices_id_seq OWNED BY active_devices.id;


--
-- Name: publication_reports; Type: TABLE; Schema: public; Owner: orrbarkat; Tablespace: 
--

CREATE TABLE publication_reports (
    id integer NOT NULL,
    publication_id integer NOT NULL,
    publication_version integer NOT NULL,
    report integer,
    active_device_dev_uuid character varying(64) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    date_of_report numeric
);


ALTER TABLE publication_reports OWNER TO orrbarkat;

--
-- Name: publication_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: orrbarkat
--

CREATE SEQUENCE publication_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE publication_reports_id_seq OWNER TO orrbarkat;

--
-- Name: publication_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orrbarkat
--

ALTER SEQUENCE publication_reports_id_seq OWNED BY publication_reports.id;


--
-- Name: publications; Type: TABLE; Schema: public; Owner: orrbarkat; Tablespace: 
--

CREATE TABLE publications (
    id integer NOT NULL,
    version integer NOT NULL,
    title character varying(200) NOT NULL,
    subtitle text,
    address character varying(100) NOT NULL,
    type_of_collecting integer,
    latitude numeric NOT NULL,
    longitude numeric NOT NULL,
    starting_date numeric,
    ending_date numeric NOT NULL,
    contact_info character varying(100),
    is_on_air boolean,
    active_device_dev_uuid character varying(64) NOT NULL,
    photo_url character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE publications OWNER TO orrbarkat;

--
-- Name: publications_id_seq; Type: SEQUENCE; Schema: public; Owner: orrbarkat
--

CREATE SEQUENCE publications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE publications_id_seq OWNER TO orrbarkat;

--
-- Name: publications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orrbarkat
--

ALTER SEQUENCE publications_id_seq OWNED BY publications.id;


--
-- Name: registered_user_for_publications; Type: TABLE; Schema: public; Owner: orrbarkat; Tablespace: 
--

CREATE TABLE registered_user_for_publications (
    id integer NOT NULL,
    publication_id integer NOT NULL,
    active_device_dev_uuid character varying(64) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    publication_version integer,
    date_of_registration numeric
);


ALTER TABLE registered_user_for_publications OWNER TO orrbarkat;

--
-- Name: registered_user_for_publications_id_seq; Type: SEQUENCE; Schema: public; Owner: orrbarkat
--

CREATE SEQUENCE registered_user_for_publications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE registered_user_for_publications_id_seq OWNER TO orrbarkat;

--
-- Name: registered_user_for_publications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orrbarkat
--

ALTER SEQUENCE registered_user_for_publications_id_seq OWNED BY registered_user_for_publications.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: orrbarkat; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE schema_migrations OWNER TO orrbarkat;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: orrbarkat
--

ALTER TABLE ONLY active_devices ALTER COLUMN id SET DEFAULT nextval('active_devices_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: orrbarkat
--

ALTER TABLE ONLY publication_reports ALTER COLUMN id SET DEFAULT nextval('publication_reports_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: orrbarkat
--

ALTER TABLE ONLY publications ALTER COLUMN id SET DEFAULT nextval('publications_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: orrbarkat
--

ALTER TABLE ONLY registered_user_for_publications ALTER COLUMN id SET DEFAULT nextval('registered_user_for_publications_id_seq'::regclass);


--
-- Data for Name: active_devices; Type: TABLE DATA; Schema: public; Owner: orrbarkat
--

COPY active_devices (id, remote_notification_token, is_ios, last_location_latitude, last_location_longitude, dev_uuid, created_at, updated_at) FROM stdin;
\.
COPY active_devices (id, remote_notification_token, is_ios, last_location_latitude, last_location_longitude, dev_uuid, created_at, updated_at) FROM '$$PATH$$/2295.dat';

--
-- Name: active_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orrbarkat
--

SELECT pg_catalog.setval('active_devices_id_seq', 188, true);


--
-- Data for Name: publication_reports; Type: TABLE DATA; Schema: public; Owner: orrbarkat
--

COPY publication_reports (id, publication_id, publication_version, report, active_device_dev_uuid, created_at, updated_at, date_of_report) FROM stdin;
\.
COPY publication_reports (id, publication_id, publication_version, report, active_device_dev_uuid, created_at, updated_at, date_of_report) FROM '$$PATH$$/2297.dat';

--
-- Name: publication_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orrbarkat
--

SELECT pg_catalog.setval('publication_reports_id_seq', 104, true);


--
-- Data for Name: publications; Type: TABLE DATA; Schema: public; Owner: orrbarkat
--

COPY publications (id, version, title, subtitle, address, type_of_collecting, latitude, longitude, starting_date, ending_date, contact_info, is_on_air, active_device_dev_uuid, photo_url, created_at, updated_at) FROM stdin;
\.
COPY publications (id, version, title, subtitle, address, type_of_collecting, latitude, longitude, starting_date, ending_date, contact_info, is_on_air, active_device_dev_uuid, photo_url, created_at, updated_at) FROM '$$PATH$$/2299.dat';

--
-- Name: publications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orrbarkat
--

SELECT pg_catalog.setval('publications_id_seq', 421, true);


--
-- Data for Name: registered_user_for_publications; Type: TABLE DATA; Schema: public; Owner: orrbarkat
--

COPY registered_user_for_publications (id, publication_id, active_device_dev_uuid, created_at, updated_at, publication_version, date_of_registration) FROM stdin;
\.
COPY registered_user_for_publications (id, publication_id, active_device_dev_uuid, created_at, updated_at, publication_version, date_of_registration) FROM '$$PATH$$/2301.dat';

--
-- Name: registered_user_for_publications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orrbarkat
--

SELECT pg_catalog.setval('registered_user_for_publications_id_seq', 649, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: orrbarkat
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/2303.dat';

--
-- Name: active_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: orrbarkat; Tablespace: 
--

ALTER TABLE ONLY active_devices
    ADD CONSTRAINT active_devices_pkey PRIMARY KEY (id);


--
-- Name: publication_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: orrbarkat; Tablespace: 
--

ALTER TABLE ONLY publication_reports
    ADD CONSTRAINT publication_reports_pkey PRIMARY KEY (id);


--
-- Name: publications_pkey; Type: CONSTRAINT; Schema: public; Owner: orrbarkat; Tablespace: 
--

ALTER TABLE ONLY publications
    ADD CONSTRAINT publications_pkey PRIMARY KEY (id);


--
-- Name: registered_user_for_publications_pkey; Type: CONSTRAINT; Schema: public; Owner: orrbarkat; Tablespace: 
--

ALTER TABLE ONLY registered_user_for_publications
    ADD CONSTRAINT registered_user_for_publications_pkey PRIMARY KEY (id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: orrbarkat; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: orrbarkat
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM orrbarkat;
GRANT ALL ON SCHEMA public TO orrbarkat;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

